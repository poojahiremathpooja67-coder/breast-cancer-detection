# Breast Cancer Detection

## Synopsis
This project uses machine learning to classify breast tumor data into two categories: benign and malignant.

## Objectives
- Understand the breast cancer dataset.
- Clean and prepare the data.
- Analyze important tumor features.
- Train a classification model.
- Predict whether a tumor is benign or malignant.
- Evaluate model accuracy.

## Tools
Python, Pandas, Matplotlib, Scikit-learn

## Dataset
The project uses the Breast Cancer Wisconsin Diagnostic dataset available through Scikit-learn.

Target classes:
- Benign
- Malignant

The dataset contains numerical tumor measurements such as radius, texture, perimeter, area, smoothness, compactness, concavity, symmetry, and fractal dimension.

## Data Preparation
- Checked the dataset for missing values.
- Separated features from the diagnosis target.
- Split the data into training and testing sets.
- Standardized numerical features using StandardScaler.

## Machine Learning Algorithm
Logistic Regression is used as the binary classification algorithm.

## Evaluation
The program calculates:
- Accuracy
- Classification report
- Confusion matrix

## How to Run
1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:
   pip install -r requirements.txt
4. Run:
   python breast_cancer_detection.py

The program prints dataset information, missing-value checks, diagnosis distribution, model accuracy, classification metrics, and an example prediction. It also creates `breast_cancer_features.png`.

## Important Note
This is an educational machine-learning project and is not intended for medical diagnosis or clinical decision-making.
