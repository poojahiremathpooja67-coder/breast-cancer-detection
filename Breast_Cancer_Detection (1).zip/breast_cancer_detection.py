# Breast Cancer Detection
# Tools: Python, Pandas, Matplotlib, Scikit-learn

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load dataset
data = pd.read_csv("breast_cancer.csv")

print("First 5 rows:")
print(data.head())

print("\nDataset shape:", data.shape)

print("\nMissing values:")
print(data.isnull().sum().sum())

print("\nDiagnosis distribution:")
print(data["diagnosis"].value_counts())

# Separate features and target
X = data.drop(columns=["diagnosis"])
y = data["diagnosis"]

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Standardize features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train classification model
model = LogisticRegression(max_iter=5000, random_state=42)
model.fit(X_train_scaled, y_train)

# Predictions
y_pred = model.predict(X_test_scaled)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"\nModel Accuracy: {accuracy * 100:.2f}%")

print("\nClassification Report:")
print(classification_report(y_test, y_pred))

print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Predict a new tumor using the first test sample as an example
sample = X_test.iloc[[0]]
sample_scaled = scaler.transform(sample)
prediction = model.predict(sample_scaled)[0]
print("\nExample tumor prediction:", prediction)

# Feature visualization
plt.figure(figsize=(8, 5))
plt.scatter(
    data["mean radius"],
    data["mean texture"],
    c=(data["diagnosis"] == "malignant").astype(int),
    alpha=0.7
)
plt.xlabel("Mean Radius")
plt.ylabel("Mean Texture")
plt.title("Breast Tumor Feature Analysis")
plt.tight_layout()
plt.savefig("breast_cancer_features.png", dpi=150)
plt.show()
